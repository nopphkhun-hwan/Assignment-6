const express = require('express');
const fs = require('fs');
const path = require('path');

const app = express();
const FILE = path.join(__dirname, 'books.json');

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const readBooks = () => JSON.parse(fs.readFileSync(FILE, 'utf8'));
const writeBooks = (books) => fs.writeFileSync(FILE, JSON.stringify(books, null, 2));

// Step 2
app.get('/api/books', (req, res) => {
  res.status(200).json(readBooks());
});

// Step 5
app.get('/api/book/:isbn', (req, res) => {
  const book = readBooks().find((b) => b.isbn === req.params.isbn);
  if (!book) {
    return res.status(404).json({ status: false, message: 'Book not found' });
  }
  res.status(200).json(book);
});

// Step 6
app.post('/api/book', (req, res) => {
  const { isbn, title, author, year, publisher } = req.body;
  const book = { isbn, title, author, year, publisher, status: 'available' };

  const books = readBooks();
  books.push(book);
  writeBooks(books);

  res.status(201).json(book);
});

app.listen(3000, () => console.log('http://localhost:3000'));
